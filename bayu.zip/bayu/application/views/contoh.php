<html>
  <head>
    <title>Contoh</title>
  </head>
  <bod>
    <h1>Hello dunia</h1>
    <a href="<?php base_url();?>index.php/Sofyan">Pergi halaman selanjutnya</a>
  </bod>
</html>