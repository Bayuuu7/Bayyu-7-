<div class="container">
    <div class="page-inner">
        
        <form action="#" method="post">
        <p>namahp: <input type="text" name="nama_hp"></p>
        <p>merek: <input type="text" name="merk"></p>
        <p>stok barang: <input type="text" name="stok"></p>
        <p>ram: <input type="text" name="ram"></p>
        <p>penyimpanan: <input type="text" name="penyimpanan"></p>
        <p>harga: <input type="text" name="harga"></p>
        
        <button class="btn btn-primary">Tambah</button>
        </form>
        
    </div>
</div>