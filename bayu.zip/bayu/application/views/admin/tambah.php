<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Form Input HP</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
  <div class="max-w-xl mx-auto bg-white p-8 rounded-2xl shadow-md">
    <h2 class="text-2xl font-semibold mb-6 text-gray-800">Form Input Data HP</h2>
    <?php echo form_open_multipart('admin/dashboard_admin/insert'); ?>
      <div>
        <label class="block text-gray-700 font-medium">ID</label>
        <input name="id" type="text" id="id" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>
      <div>
        <label class="block text-gray-700 font-medium">Nama HP</label>
        <input name="nama_hp" type="text" id="nama" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>
      <div>
        <label class="block text-gray-700 font-medium">Merek</label>
        <input name="merk" type="text" id="merek" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>
      <div>
        <label class="block text-gray-700 font-medium">RAM (GB)</label>
        <input name="ram" type="number" id="ram" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>
      <div>
        <label class="block text-gray-700 font-medium">Penyimpanan (GB)</label>
        <input name="penyimpanan" type="number" id="penyimpanan" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>
      <div>
        <label class="block text-gray-700 font-medium">Harga (Rp)</label>
        <input name="harga" type="number" id="harga" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>
      <div>
        <label class="block text-gray-700 font-medium">Stok</label>
        <input name="stok" type="number" id="stok" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>
      <div>
        <label class="block text-gray-700 font-medium">Gambar</label>
        <input name="foto" type="file" id="gambar" accept="img/" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>
      <button type="submit" class="w-full bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition">Simpan</button>
      <?php echo form_close(); ?>
    <br>
    <a href="<?php echo site_url('admin/dashboard_admin/index') ?>">Kembali</a>
  </div>
  
</body>
</html>