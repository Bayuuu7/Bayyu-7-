<div class="container">
          <div class="page-inner">
          <div class="card">
        <div class="card-body">
            <h5 class="card-title">Data Barang</h5>
            <a class="btn btn-sm btn-primary mb-3" href="<?php echo site_url('/admin/dashboard_admin/tambah');?>">Tambah</a>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>NAMA HANDPHONE</th>
                            <th>MERK</th>
                            <th>RAM</th>
                            <th>PENYIMPANAN</th>
                            <th>STOK</th>
                            <th>HARGA</th>
                            <th>GAMBAR</th>
                        </tr>
                    </thead>
                    <tbody>
                      
                      <?php 
                      $no = 1;
                      foreach($hp as $brg): ?>
                      
                            <tr>
                               <td><?php echo $no++ ?></td>
                               <td><?php echo $brg->nama_hp ?></td>
                               <td><?php echo $brg->merk ?></td>
                               <td><?php echo $brg->ram ?></td>
                               <td><?php echo $brg->penyimpanan ?></td>
                               <td><?php echo $brg->stok ?></td>
                               <td><?php echo $brg->harga ?></td>
                            <td><img src="<?php echo base_url($brg->foto) ?>" width="100"></td>
                            </tr>
                            
                      <?php endforeach; ?>
                            
                    </tbody>
                </table>
            </div>
        </div>
    </div>
          </div>
        </div>