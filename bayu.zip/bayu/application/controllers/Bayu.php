<?php
class Bayu extends CI_Controller {
  
  public function index() {
    $this->load->view("template/head");
    $this->load->view("template/sidebar");
    $this->load->view("Bayu_v");
    $this->load->view("template/footer");
  }
}