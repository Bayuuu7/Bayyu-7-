<?php

class dashboard extends CI_Controller {
  
  public function index() {
    $this->load->model("bayu_m");
    $data['hp'] = $this->bayu_m->get();
    
    $this->load->view("template/head");
    $this->load->view("template/sidebar");
    $this->load->view("dashboard", $data);
    $this->load->view("template/footer");
  }
  
}

?>