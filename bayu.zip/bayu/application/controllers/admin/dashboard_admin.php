<?php

class Dashboard_admin extends CI_Controller {
  
  public function __construct() {
    parent::__construct();
    $this->load->model("bayu_m");
  }
  
  public function index() {
    $this->load->view("template_admin/head");
    $this->load->view("template_admin/sidebar");
    $this->load->view("admin/dashboard");
    $this->load->view("template_admin/footer");
  }
  
  public function tambah() {
    $this->load->view("admin/tambah");
  }
  
  public function data() {
    $data['hp'] = $this->bayu_m->get();
    
    $this->load->view("template_admin/head");
    $this->load->view("template_admin/sidebar");
    $this->load->view("admin/data", $data);
    $this->load->view("template_admin/footer");
  }
  
  public function insert() {
    $id = $this->input->post("id");
    $nama_hp = $this->input->post("nama_hp");
    $merk = $this->input->post("merk");
    $ram = $this->input->post("ram");
    $penyimpanan = $this->input->post('penyimpanan');
    $harga = $this->input->post("harga");
    $stok = $this->input->post('stok');
    $foto = $_FILES['foto']['tmp_name'];
    $path = 'assets/img/';
    $imagespath = $path. $username. 'redmi.jpg';
    $imagespath = $path. $username. 'vivo.jpg';
    $imagespath = $path. $username. 'iphone.jpg';
    $imagespath = $path. $username. 'relmi.jpg';
    $imagespath = $path. $username. 'infinix.jpg';
    $imagespath = $path. $username. 'smart.jpg';
    $imagespath = $path. $username. 'relmi15.png';
    $imagespath = $path. $username. 'a.jpg';
    move_uploaded_file($foto, $imagespath);
    
    $data = array(
      'id' => $id,
      'nama_hp' => $nama_hp,
      'merk' => $merk,
      'ram' => $ram,
      'penyimpanan' => $penyimpanan,
      'harga' => $harga,
      'stok' => $stok,
      'foto' => $imagespath,
      );
      
      $this->bayu_m->aksi_insert($data, 'hp');
      redirect('admin/dashboard_admin/data');
  }
  
}

?>