<?php
class Barang extends CI_Controller {
  
  public function index() {
    $this->load->view("template/head");
    $this->load->view("template/sidebar");
    $this->load->view("barang");
    $this->load->view("template/footer");
  }

  public function tambah() {
    $this->load->view("template/head");
    $this->load->view("template/sidebar");
    $this->load->view("tambah");
    $this->load->view("template/footer");
  }
}