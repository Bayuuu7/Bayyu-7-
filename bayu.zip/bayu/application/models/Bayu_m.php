<?php
class Bayu_m extends CI_Model {
  public function get(){
    return $this->db->get('hp')->result();
  }
  
  public function aksi_insert($data) {
    return $this->db->insert('hp', $data);
  }
}